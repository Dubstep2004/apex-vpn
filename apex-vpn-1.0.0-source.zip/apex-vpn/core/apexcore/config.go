package apexcore

import (
	"encoding/json"
	"errors"
	"fmt"
)

// AutoTag is the outbound that picks the fastest server automatically.
const AutoTag = "auto"

// BuildConfig takes the "nodes" array from ParseSubscription (as JSON)
// and the tag to use ("auto" or a node tag), and returns a full sing-box
// config with a TUN inbound for Android.
func BuildConfig(nodesJSON string, selectedTag string) (string, error) {
	var nodes []Node
	if err := json.Unmarshal([]byte(nodesJSON), &nodes); err != nil {
		return "", fmt.Errorf("неверный список серверов: %w", err)
	}
	if len(nodes) == 0 {
		return "", errors.New("нет серверов")
	}

	tags := make([]string, 0, len(nodes))
	outbounds := make([]any, 0, len(nodes)+3)
	found := selectedTag == AutoTag
	for _, n := range nodes {
		if n.Outbound == nil || n.Tag == "" {
			continue
		}
		n.Outbound["tag"] = n.Tag
		tags = append(tags, n.Tag)
		if n.Tag == selectedTag {
			found = true
		}
	}
	if len(tags) == 0 {
		return "", errors.New("нет серверов")
	}
	if !found {
		selectedTag = AutoTag
	}

	outbounds = append(outbounds,
		map[string]any{
			"type":                        "selector",
			"tag":                         "proxy",
			"outbounds":                   append([]string{AutoTag}, tags...),
			"default":                     selectedTag,
			"interrupt_exist_connections": true,
		},
		map[string]any{
			"type":                        "urltest",
			"tag":                         AutoTag,
			"outbounds":                   tags,
			"url":                         "https://www.gstatic.com/generate_204",
			"interval":                    "3m",
			"tolerance":                   80,
			"interrupt_exist_connections": true,
		},
	)
	for _, n := range nodes {
		if n.Outbound != nil && n.Tag != "" {
			outbounds = append(outbounds, n.Outbound)
		}
	}
	outbounds = append(outbounds, map[string]any{"type": "direct", "tag": "direct"})

	cfg := map[string]any{
		"log": map[string]any{"level": "warn", "timestamp": true},
		"dns": map[string]any{
			"servers": []any{
				map[string]any{"type": "https", "tag": "remote", "server": "1.1.1.1", "detour": "proxy"},
				map[string]any{"type": "local", "tag": "local"},
			},
			"final":    "remote",
			"strategy": "ipv4_only",
		},
		"inbounds": []any{
			map[string]any{
				"type":         "tun",
				"tag":          "tun-in",
				"address":      []string{"172.19.0.1/30", "fdfe:dcba:9876::1/126"},
				"mtu":          9000,
				"auto_route":   true,
				"strict_route": true,
				"stack":        "mixed",
			},
		},
		"outbounds": outbounds,
		"route": map[string]any{
			"rules": []any{
				map[string]any{"action": "sniff"},
				map[string]any{"protocol": "dns", "action": "hijack-dns"},
				map[string]any{"ip_is_private": true, "outbound": "direct"},
			},
			"final":                   "proxy",
			"auto_detect_interface":   true,
			"default_domain_resolver": "local",
		},
	}
	out, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return "", err
	}
	return string(out), nil
}
