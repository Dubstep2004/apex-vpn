package apexcore

import (
	"encoding/base64"
	"encoding/json"
	"strings"
	"testing"

	"github.com/sagernet/sing-box/experimental/libbox"
)

const (
	testUUID = "b831381d-6324-4d53-ad4f-8cda48b30811"
	testPBK  = "Z84J2IelR9ch3k8VtlVhhs5ycBUlXA7wHBWcBrjqnAw"
)

func sampleLinks() []string {
	vmess := base64.StdEncoding.EncodeToString([]byte(`{"v":"2","ps":"VMess WS","add":"vm.example.com","port":"443","id":"` + testUUID + `","aid":"0","scy":"auto","net":"ws","type":"none","host":"vm.example.com","path":"/ws?ed=2048","tls":"tls","sni":"vm.example.com","fp":"chrome"}`))
	ss := base64.RawURLEncoding.EncodeToString([]byte("chacha20-ietf-poly1305:pass123"))
	return []string{
		"vless://" + testUUID + "@1.2.3.4:443?type=tcp&security=reality&pbk=" + testPBK + "&fp=chrome&sni=www.microsoft.com&sid=6ba85179e30d4fc2&flow=xtls-rprx-vision#%F0%9F%87%B3%F0%9F%87%B1%20Netherlands",
		"vless://" + testUUID + "@vl.example.com:443?type=grpc&serviceName=grpcsvc&security=tls&sni=vl.example.com&alpn=h2#gRPC",
		"vless://" + testUUID + "@vl.example.com:8080?type=ws&path=%2Fws&host=vl.example.com&security=none#WS%20plain",
		"vmess://" + vmess,
		"trojan://secret@tr.example.com:443?security=tls&type=tcp&sni=tr.example.com#Trojan",
		"ss://" + ss + "@5.6.7.8:8388#SS",
		"hysteria2://authpass@hy.example.com:443?sni=hy.example.com&obfs=salamander&obfs-password=x&insecure=1#Hy2",
		"tuic://" + testUUID + ":pw@tu.example.com:443?congestion_control=bbr&alpn=h3#TUIC",
		"vless://" + testUUID + "@x.example.com:443?type=xhttp&security=tls#XHTTP",
		"wireguard://abc@1.1.1.1:51820#WG",
	}
}

func TestParseBase64Subscription(t *testing.T) {
	body := base64.StdEncoding.EncodeToString([]byte(strings.Join(sampleLinks(), "\n")))
	out, err := ParseSubscription(body)
	if err != nil {
		t.Fatal(err)
	}
	var res parseResult
	if err := json.Unmarshal([]byte(out), &res); err != nil {
		t.Fatal(err)
	}
	if len(res.Nodes) != 8 {
		t.Fatalf("want 8 nodes, got %d (skipped: %v)", len(res.Nodes), res.Skipped)
	}
	if len(res.Skipped) != 2 {
		t.Fatalf("want 2 skipped, got %v", res.Skipped)
	}
	if res.Nodes[0].Name != "🇳🇱 Netherlands" {
		t.Fatalf("bad name %q", res.Nodes[0].Name)
	}
	nodes, _ := json.Marshal(res.Nodes)

	for _, sel := range []string{AutoTag, "node-1", "node-4", "missing"} {
		cfg, err := BuildConfig(string(nodes), sel)
		if err != nil {
			t.Fatal(err)
		}
		if err := libbox.CheckConfig(cfg); err != nil {
			t.Fatalf("sing-box rejected config (%s): %v\n%s", sel, err, cfg)
		}
	}
}

func TestParsePlainAndSingBoxJSON(t *testing.T) {
	if _, err := ParseSubscription(strings.Join(sampleLinks()[:2], "\r\n")); err != nil {
		t.Fatal(err)
	}
	sb := `{"outbounds":[{"type":"selector","tag":"s","outbounds":["a"]},{"type":"vless","tag":"a","server":"1.2.3.4","server_port":443,"uuid":"` + testUUID + `"},{"type":"direct","tag":"direct"}]}`
	out, err := ParseSubscription(sb)
	if err != nil {
		t.Fatal(err)
	}
	var res parseResult
	json.Unmarshal([]byte(out), &res)
	if len(res.Nodes) != 1 || res.Nodes[0].Name != "a" {
		t.Fatalf("unexpected %v", out)
	}
	nodes, _ := json.Marshal(res.Nodes)
	cfg, err := BuildConfig(string(nodes), AutoTag)
	if err != nil {
		t.Fatal(err)
	}
	if err := libbox.CheckConfig(cfg); err != nil {
		t.Fatal(err)
	}
}

func TestErrors(t *testing.T) {
	if _, err := ParseSubscription(""); err == nil {
		t.Fatal("empty must fail")
	}
	if _, err := ParseSubscription("<html>nope</html>"); err == nil {
		t.Fatal("html must fail")
	}
}
