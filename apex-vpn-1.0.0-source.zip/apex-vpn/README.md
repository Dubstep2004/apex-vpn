# APEX VPN 1.0.0

VPN-клиент для Android, работающий только с подпиской `https://sub.knownhosts.ru/…`.

- **Ядро** — sing-box 1.13.21: VLESS (Reality, Vision, WS, gRPC, HTTPUpgrade), VMess, Trojan, Shadowsocks, Hysteria2, TUIC.
- **Подписка** — только хост `sub.knownhosts.ru` (проверяется при вводе и после редиректов). Понимает base64-список ссылок, обычный список и JSON sing-box. Показывает трафик и срок действия из заголовка `subscription-userinfo`, автообновляется раз в 12 ч (или как задаст заголовок `profile-update-interval`).
- **Серверы** — режим «Авто» (самый быстрый по замеру) или ручной выбор, замер задержки, смена сервера без разрыва VPN.
- **Обновление приложения** — с вашего сервера: проверка при запуске и вручную в настройках, загрузка с прогрессом, проверка SHA-256, установка. Поддерживаются обязательные обновления.
- Android 7.0+ (minSdk 24), APK для arm64-v8a и armeabi-v7a.

## Структура

```
app/                    Android-приложение (Kotlin, Jetpack Compose)
  src/main/java/com/apexvpn/client/
    vpn/                VpnService + связка с ядром sing-box
    data/               подписка, настройки, замер задержки
    update/             обновление приложения
    ui/                 экраны
core/apexcore/          Go: разбор подписки → конфиг sing-box (+ тесты)
core/build-core.sh      сборка ядра в app/libs/libbox.aar
design/icon.svg         исходник иконки
server/update.json      пример файла обновления для вашего сервера
.github/workflows/      сборка APK в GitHub Actions
```

## Сборка через GitHub Actions (проще всего)

1. Создайте репозиторий на GitHub и загрузите туда проект.
2. Один раз создайте ключ подписи: `./scripts/make-keystore.sh`. Добавьте в **Settings → Secrets and variables → Actions → Secrets**: `APEX_KEYSTORE_BASE64`, `APEX_KEYSTORE_PASSWORD`, `APEX_KEY_ALIAS`, `APEX_KEY_PASSWORD` (скрипт подскажет значения).
3. В **Variables** добавьте:
   - `UPDATE_URL` — адрес update.json, например `https://ваш-сайт/apexvpn/update.json`
   - `APK_BASE_URL` — папка, где будут лежать APK, например `https://ваш-сайт/apexvpn`
4. Запушьте в `main` (или запустите workflow вручную). Через ~15 минут в **Actions → артефакты** будут `apex-vpn-1.0.0.apk` и готовый `update.json`. При пуше тега `v1.0.0` создастся GitHub Release.

> Ключ подписи нельзя терять: Android ставит обновление только поверх приложения, подписанного тем же ключом.

## Локальная сборка

Нужны JDK 17, Go 1.25+, Android SDK и NDK `28.0.13004108`.

```bash
export ANDROID_HOME=~/Android/Sdk
./core/build-core.sh                      # ядро → app/libs/libbox.aar
./gradlew assembleRelease -PupdateUrl=https://ваш-сайт/apexvpn/update.json
# APK: app/build/outputs/apk/release/app-release.apk
```

## Как выпустить обновление

1. В `app/build.gradle.kts` увеличьте `versionCode` (2, 3, …) и `versionName` (`1.0.1`, …).
2. Соберите APK (Actions сделает и `update.json` с SHA-256).
3. Загрузите на свой сервер **сначала APK**, затем **update.json** по адресу `UPDATE_URL`.
4. Приложения у пользователей увидят обновление при следующем запуске.

Поля `update.json`:

| поле | смысл |
|---|---|
| `versionCode` | номер сборки; обновление показывается, если он больше установленного |
| `versionName` | версия для пользователя |
| `apkUrl` | прямая https-ссылка на APK |
| `sha256` | контрольная сумма APK (рекомендуется) |
| `changelog` | что нового |
| `mandatory` | `true` — обновление нельзя отложить |
| `minSupportedVersionCode` | версии ниже этого номера обязаны обновиться |

## Заметки

- Ядро sing-box распространяется по лицензии GPL-3.0, поэтому и приложение с ним должно распространяться на условиях GPL-3.0 (с открытым исходным кодом).
- Протоколы XHTTP/SplitHTTP и плагины Shadowsocks ядро sing-box не поддерживает — такие серверы из подписки пропускаются.
- Чтобы получить список ссылок, приложение запрашивает подписку с User-Agent, совместимым с v2rayNG: панели (Marzban, Remnawave, 3x-ui) отдают на него стандартный формат.
