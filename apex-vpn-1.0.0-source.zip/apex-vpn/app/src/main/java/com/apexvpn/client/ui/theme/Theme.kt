package com.apexvpn.client.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Apex {
    val Bg = Color(0xFF0B0E1A)
    val Surface = Color(0xFF141A30)
    val SurfaceHigh = Color(0xFF1C2342)
    val Outline = Color(0xFF2A3358)
    val Cyan = Color(0xFF22D3EE)
    val CyanLight = Color(0xFFA5F3FC)
    val Violet = Color(0xFF7C3AED)
    val Text = Color(0xFFE8ECFF)
    val TextDim = Color(0xFF8B93B8)
    val Good = Color(0xFF34D399)
    val Warn = Color(0xFFFBBF24)
    val Bad = Color(0xFFF87171)

    val accent = Brush.linearGradient(listOf(Violet, Cyan))
}

private val scheme = darkColorScheme(
    primary = Apex.Cyan,
    onPrimary = Apex.Bg,
    secondary = Apex.Violet,
    onSecondary = Color.White,
    background = Apex.Bg,
    onBackground = Apex.Text,
    surface = Apex.Surface,
    onSurface = Apex.Text,
    surfaceVariant = Apex.SurfaceHigh,
    onSurfaceVariant = Apex.TextDim,
    surfaceContainer = Apex.Surface,
    surfaceContainerHigh = Apex.SurfaceHigh,
    surfaceContainerHighest = Apex.SurfaceHigh,
    outline = Apex.Outline,
    error = Apex.Bad,
)

@Composable
fun ApexTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
