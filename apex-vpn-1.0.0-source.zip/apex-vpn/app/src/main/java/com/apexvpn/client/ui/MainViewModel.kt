package com.apexvpn.client.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.apexvpn.client.data.Pinger
import com.apexvpn.client.data.Subscription
import com.apexvpn.client.update.UpdateManager
import com.apexvpn.client.vpn.ApexVpnService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val subscription = Subscription.state
    val update = UpdateManager.state

    private val _refreshing = MutableStateFlow(false)
    val refreshing = _refreshing.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()

    private val _pings = MutableStateFlow<Map<String, Int>>(emptyMap())
    val pings = _pings.asStateFlow()

    private val _pinging = MutableStateFlow(false)
    val pinging = _pinging.asStateFlow()

    init {
        viewModelScope.launch {
            if (Subscription.needsRefresh()) refresh(silent = true)
        }
        viewModelScope.launch { UpdateManager.check(silent = true) }
    }

    fun refresh(silent: Boolean = false) {
        if (_refreshing.value) return
        viewModelScope.launch {
            _refreshing.value = true
            try {
                Subscription.refresh()
                ApexVpnService.reload(getApplication<Application>())
                if (!silent) _message.value = "Подписка обновлена"
            } catch (e: Exception) {
                if (!silent) _message.value = e.message ?: "Не удалось обновить подписку"
            } finally {
                _refreshing.value = false
            }
        }
    }

    /** Добавить подписку. onDone(null) — успех, иначе текст ошибки. */
    fun setSubscription(url: String, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            _refreshing.value = true
            try {
                Subscription.setUrl(url)
                ApexVpnService.reload(getApplication<Application>())
                onDone(null)
            } catch (e: Exception) {
                onDone(e.message ?: "Не удалось загрузить подписку")
            } finally {
                _refreshing.value = false
            }
        }
    }

    fun removeSubscription() {
        ApexVpnService.stop(getApplication<Application>())
        Subscription.remove()
        _pings.value = emptyMap()
    }

    fun select(tag: String) {
        Subscription.select(tag)
        ApexVpnService.reload(getApplication<Application>())
    }

    fun pingAll() {
        if (_pinging.value) return
        viewModelScope.launch {
            _pinging.value = true
            try {
                _pings.value = Pinger.pingAll(Subscription.state.value.nodes)
            } finally {
                _pinging.value = false
            }
        }
    }

    fun checkUpdate() {
        // Ручная проверка всегда показывает диалог, даже если ранее нажали «Позже»
        com.apexvpn.client.data.Prefs.dismissedUpdateCode = 0
        viewModelScope.launch { UpdateManager.check(silent = false) }
    }

    fun downloadUpdate(info: com.apexvpn.client.update.UpdateInfo) {
        viewModelScope.launch { UpdateManager.download(getApplication<Application>(), info) }
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun showMessage(text: String) {
        _message.value = text
    }
}
