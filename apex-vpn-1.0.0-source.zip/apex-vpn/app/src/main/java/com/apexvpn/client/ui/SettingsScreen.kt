package com.apexvpn.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.apexvpn.client.BuildConfig
import com.apexvpn.client.ui.theme.Apex
import com.apexvpn.client.update.UpdateState

@Composable
fun SettingsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val sub by viewModel.subscription.collectAsStateWithLifecycle()
    val update by viewModel.update.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = Apex.Text)
            }
            Text("Настройки", color = Apex.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            Section("Подписка") {
                Item(Icons.Rounded.Link, "Ссылка", maskUrl(sub.url))
                Item(Icons.Rounded.Edit, "Изменить ссылку", null) { editing = true }
                Item(Icons.Rounded.Delete, "Удалить подписку", null, tint = Apex.Bad) { confirmRemove = true }
            }

            Section("Обновления") {
                val (subtitle, busy) = when (val s = update) {
                    UpdateState.Checking -> "Проверяем…" to true
                    UpdateState.UpToDate -> "У вас последняя версия" to false
                    is UpdateState.Available -> "Доступна версия ${s.info.versionName}" to false
                    is UpdateState.Downloading -> "Загрузка ${(s.progress * 100).toInt()}%" to true
                    is UpdateState.ReadyToInstall -> "Версия ${s.info.versionName} готова к установке" to false
                    is UpdateState.Failed -> s.message to false
                    UpdateState.Idle -> "Нажмите, чтобы проверить" to false
                }
                Item(
                    Icons.Rounded.SystemUpdate,
                    "Проверить обновления",
                    subtitle,
                    trailing = {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Apex.Cyan)
                    },
                ) { if (!busy) viewModel.checkUpdate() }
            }

            Section("О приложении") {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    ApexLogo(48.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("APEX VPN", color = Apex.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("Версия ${BuildConfig.VERSION_NAME}", color = Apex.TextDim, fontSize = 13.sp)
                        Text(
                            "Ядро sing-box ${runCatching { io.nekohasekai.libbox.Libbox.version() }.getOrDefault("")}",
                            color = Apex.TextDim,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (editing) {
        AlertDialog(
            onDismissRequest = { editing = false },
            containerColor = Apex.Surface,
            title = { Text("Новая ссылка", color = Apex.Text) },
            text = {
                Column {
                    SubscriptionInput(viewModel, buttonText = "Сохранить") {
                        editing = false
                        viewModel.showMessage("Подписка обновлена")
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { editing = false }) { Text("Отмена") } },
        )
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            containerColor = Apex.Surface,
            title = { Text("Удалить подписку?", color = Apex.Text) },
            text = { Text("VPN будет отключён, список серверов очищен.", color = Apex.TextDim) },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = false
                    viewModel.removeSubscription()
                }) { Text("Удалить", color = Apex.Bad) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Отмена") } },
        )
    }
}

private fun maskUrl(url: String): String {
    val idx = url.indexOf('/', "https://".length)
    if (idx < 0) return url
    val path = url.substring(idx + 1)
    val masked = if (path.length > 6) path.take(3) + "•••" + path.takeLast(3) else "•••"
    return url.substring(0, idx + 1) + masked
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Spacer(Modifier.height(16.dp))
    Text(title.uppercase(), color = Apex.TextDim, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Apex.Surface)
            .border(1.dp, Apex.Outline, RoundedCornerShape(18.dp)),
        content = content,
    )
}

@Composable
private fun Item(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    tint: Color = Apex.Cyan,
    trailing: @Composable () -> Unit = {},
    onClick: (() -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (tint == Apex.Bad) Apex.Bad else Apex.Text, fontSize = 15.sp)
            if (subtitle != null) {
                Text(subtitle, color = Apex.TextDim, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing()
    }
}
