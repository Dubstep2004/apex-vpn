package com.apexvpn.client.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.apexvpn.client.data.AUTO_TAG
import com.apexvpn.client.ui.theme.Apex
import com.apexvpn.client.vpn.VpnState
import com.apexvpn.client.vpn.VpnStatus
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onToggle: () -> Unit,
    onOpenServers: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val status by VpnState.status.collectAsStateWithLifecycle()
    val error by VpnState.error.collectAsStateWithLifecycle()
    val connectedAt by VpnState.connectedAt.collectAsStateWithLifecycle()
    val sub by viewModel.subscription.collectAsStateWithLifecycle()
    val refreshing by viewModel.refreshing.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ApexWordmark()
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Rounded.Settings, "Настройки", tint = Apex.TextDim)
                }
            }

            Spacer(Modifier.height(40.dp))
            PowerButton(status, onToggle)
            Spacer(Modifier.height(24.dp))

            val (label, color) = when (status) {
                VpnStatus.Started -> "Подключено" to Apex.Good
                VpnStatus.Starting -> "Подключение…" to Apex.Cyan
                VpnStatus.Stopping -> "Отключение…" to Apex.TextDim
                VpnStatus.Stopped -> "Не подключено" to Apex.TextDim
            }
            Text(label, color = color, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            if (status == VpnStatus.Started && connectedAt > 0) {
                ConnectionTimer(connectedAt)
            } else {
                Text(
                    if (status == VpnStatus.Stopped) "Нажмите, чтобы защитить соединение" else " ",
                    color = Apex.TextDim,
                    fontSize = 14.sp,
                )
            }
            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(
                    it,
                    color = Apex.Bad,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Apex.Bad.copy(alpha = 0.12f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }

            Spacer(Modifier.height(36.dp))

            // Выбранный сервер
            val selected = sub.nodes.find { it.tag == sub.selectedTag }
            Card(onClick = onOpenServers) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Apex.Outline),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (sub.selectedTag == AUTO_TAG) Icons.Rounded.Bolt else Icons.Rounded.Public,
                        null,
                        tint = Apex.Cyan,
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Сервер", color = Apex.TextDim, fontSize = 12.sp)
                    Text(
                        if (sub.selectedTag == AUTO_TAG || selected == null) "Авто — самый быстрый" else selected.name,
                        color = Apex.Text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("${sub.nodes.size}", color = Apex.TextDim, fontSize = 13.sp)
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = Apex.TextDim)
            }

            Spacer(Modifier.height(12.dp))

            // Подписка
            Card {
                Column(Modifier.weight(1f)) {
                    Text(
                        sub.title.ifBlank { "Подписка" },
                        color = Apex.Text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(6.dp))
                    if (sub.total > 0) {
                        val used = sub.used.coerceAtLeast(0)
                        LinearProgressIndicator(
                            progress = { (used.toFloat() / sub.total).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Apex.Cyan,
                            trackColor = Apex.Outline,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("${formatBytes(used)} из ${formatBytes(sub.total)}", color = Apex.TextDim, fontSize = 13.sp)
                    } else if (sub.used >= 0) {
                        Text("Израсходовано ${formatBytes(sub.used)} · без лимита", color = Apex.TextDim, fontSize = 13.sp)
                    }
                    val expire = when {
                        sub.expireAt > 0 -> "Действует до ${formatDate(sub.expireAt)}"
                        sub.expireAt == 0L -> "Бессрочно"
                        else -> null
                    }
                    expire?.let { Text(it, color = Apex.TextDim, fontSize = 13.sp) }
                    Text("Обновлено ${formatAgo(sub.lastUpdated)}", color = Apex.TextDim, fontSize = 12.sp)
                }
                IconButton(onClick = { viewModel.refresh() }, enabled = !refreshing) {
                    if (refreshing) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Apex.Cyan)
                    } else {
                        Icon(Icons.Rounded.Refresh, "Обновить подписку", tint = Apex.Cyan)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).safeDrawingPadding())
    }
}

@Composable
private fun Card(
    onClick: (() -> Unit)? = null,
    content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Apex.Surface)
            .border(1.dp, Apex.Outline, RoundedCornerShape(18.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun ConnectionTimer(connectedAt: Long) {
    var now by remember { mutableLongStateOf(android.os.SystemClock.elapsedRealtime()) }
    LaunchedEffect(connectedAt) {
        while (true) {
            now = android.os.SystemClock.elapsedRealtime()
            delay(1000)
        }
    }
    Text(formatDuration(now - connectedAt), color = Apex.Text, fontSize = 15.sp, letterSpacing = 1.sp)
}

@Composable
private fun PowerButton(status: VpnStatus, onClick: () -> Unit) {
    val active = status == VpnStatus.Started
    val busy = status == VpnStatus.Starting || status == VpnStatus.Stopping
    val transition = rememberInfiniteTransition(label = "power")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "spin",
    )
    val iconColor by animateColorAsState(if (active) Color.White else Apex.TextDim, label = "icon")

    Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
        // Свечение
        if (active || busy) {
            Box(
                Modifier
                    .size(200.dp)
                    .scale(pulse)
                    .alpha(if (active) 0.35f else 0.2f)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Apex.Cyan, Color.Transparent))),
            )
        }
        // Кольцо
        Box(
            Modifier
                .size(184.dp)
                .rotate(if (busy) spin else 0f)
                .clip(CircleShape)
                .background(
                    if (active || busy) {
                        Brush.sweepGradient(listOf(Apex.Violet, Apex.Cyan, Apex.Violet))
                    } else {
                        Brush.linearGradient(listOf(Apex.Outline, Apex.Outline))
                    },
                ),
        )
        // Кнопка
        Box(
            Modifier
                .size(168.dp)
                .clip(CircleShape)
                .background(
                    if (active) Apex.accent else Brush.linearGradient(listOf(Apex.SurfaceHigh, Apex.Surface)),
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    enabled = status != VpnStatus.Stopping,
                    onClick = onClick,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PowerSettingsNew, "Подключить", tint = iconColor, modifier = Modifier.size(72.dp))
        }
    }
}
