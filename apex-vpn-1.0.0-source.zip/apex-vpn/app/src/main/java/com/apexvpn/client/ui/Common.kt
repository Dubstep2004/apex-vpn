package com.apexvpn.client.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvpn.client.R
import com.apexvpn.client.ui.theme.Apex
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Значок приложения (адаптивную иконку Compose не рисует, собираем из слоёв). */
@Composable
fun ApexLogo(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f)),
    ) {
        Image(painterResource(R.drawable.ic_launcher_background), null, Modifier.size(size))
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(size))
    }
}

@Composable
fun ApexWordmark(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        ApexLogo(34.dp)
        Spacer(Modifier.width(10.dp))
        Text("APEX", fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 2.sp, color = Apex.Text)
        Text(" VPN", fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = 2.sp, color = Apex.Cyan)
    }
}

@Composable
fun TypeBadge(type: String) {
    val label = when (type) {
        "vless" -> "VLESS"
        "vmess" -> "VMess"
        "trojan" -> "Trojan"
        "shadowsocks" -> "SS"
        "hysteria2" -> "Hy2"
        "tuic" -> "TUIC"
        else -> type.uppercase()
    }
    Text(
        label,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = Apex.CyanLight,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Apex.Outline)
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "—"
    val units = arrayOf("Б", "КБ", "МБ", "ГБ", "ТБ")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024; i++
    }
    return if (i == 0) "${bytes} Б" else String.format(Locale("ru"), "%.1f %s", v, units[i])
}

fun formatDate(unixSeconds: Long): String =
    SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date(unixSeconds * 1000))

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

fun formatAgo(time: Long): String {
    if (time <= 0) return "никогда"
    val min = (System.currentTimeMillis() - time) / 60_000
    return when {
        min < 1 -> "только что"
        min < 60 -> "$min мин назад"
        min < 60 * 24 -> "${min / 60} ч назад"
        else -> "${min / (60 * 24)} дн назад"
    }
}

fun pingColor(ms: Int) = when {
    ms < 0 -> Apex.TextDim
    ms < 150 -> Apex.Good
    ms < 400 -> Apex.Warn
    else -> Apex.Bad
}
