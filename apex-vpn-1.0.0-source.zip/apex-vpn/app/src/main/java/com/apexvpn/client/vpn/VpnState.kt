package com.apexvpn.client.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VpnStatus { Stopped, Starting, Started, Stopping }

/** Общее состояние VPN: сервис и интерфейс работают в одном процессе. */
object VpnState {
    private val _status = MutableStateFlow(VpnStatus.Stopped)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    /** Момент подключения (elapsedRealtime), 0 — не подключено */
    private val _connectedAt = MutableStateFlow(0L)
    val connectedAt: StateFlow<Long> = _connectedAt.asStateFlow()

    internal fun set(status: VpnStatus) {
        _status.value = status
        if (status == VpnStatus.Started) {
            _connectedAt.value = android.os.SystemClock.elapsedRealtime()
            _error.value = null
        } else if (status == VpnStatus.Stopped) {
            _connectedAt.value = 0L
        }
    }

    internal fun fail(message: String?) {
        _error.value = message ?: "Неизвестная ошибка"
    }

    fun clearError() {
        _error.value = null
    }
}
