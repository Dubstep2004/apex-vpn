package com.apexvpn.client.vpn

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.apexvpn.client.ApexApp
import com.apexvpn.client.R
import com.apexvpn.client.data.AUTO_TAG
import com.apexvpn.client.data.Subscription
import com.apexvpn.client.ui.MainActivity
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import io.nekohasekai.libbox.Notification as BoxNotification

/**
 * VPN-сервис APEX VPN: поднимает TUN-интерфейс Android и запускает
 * в нём ядро sing-box с конфигом, собранным из подписки.
 */
class ApexVpnService : VpnService(), PlatformInterface, CommandServerHandler {

    companion object {
        private const val TAG = "ApexVPN"
        private const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.apexvpn.client.START"
        const val ACTION_STOP = "com.apexvpn.client.STOP"
        const val ACTION_RELOAD = "com.apexvpn.client.RELOAD"

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, ApexVpnService::class.java).setAction(ACTION_START),
            )
        }

        fun stop(context: Context) {
            if (VpnState.status.value == VpnStatus.Stopped) return
            context.startService(Intent(context, ApexVpnService::class.java).setAction(ACTION_STOP))
        }

        /** Применить новый сервер/подписку без разрыва VPN. */
        fun reload(context: Context) {
            if (VpnState.status.value != VpnStatus.Started) return
            context.startService(Intent(context, ApexVpnService::class.java).setAction(ACTION_RELOAD))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private var commandServer: CommandServer? = null
    private var tunFd: ParcelFileDescriptor? = null

    // ─── Жизненный цикл ──────────────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> scope.launch { stopVpn() }
            ACTION_RELOAD -> scope.launch { reloadVpn() }
            else -> {
                showNotification(connected = false)
                scope.launch { startVpn() }
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        // Пользователь включил другой VPN или отозвал разрешение
        scope.launch { stopVpn() }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun startVpn() = lock.withLock {
        if (VpnState.status.value == VpnStatus.Started || VpnState.status.value == VpnStatus.Starting) {
            return@withLock
        }
        VpnState.set(VpnStatus.Starting)
        try {
            if (prepare(this) != null) error("Нет разрешения на VPN")
            val config = Subscription.buildConfig()
            NetworkMonitor.start()
            val server = CommandServer(this, this)
            server.start()
            commandServer = server
            server.startOrReloadService(config, overrideOptions())
            VpnState.set(VpnStatus.Started)
            showNotification(connected = true)
        } catch (e: Throwable) {
            Log.e(TAG, "start failed", e)
            VpnState.fail(e.message)
            shutdown()
        }
    }

    private suspend fun reloadVpn() = lock.withLock {
        val server = commandServer ?: return@withLock
        try {
            server.startOrReloadService(Subscription.buildConfig(), overrideOptions())
            showNotification(connected = true)
        } catch (e: Throwable) {
            Log.e(TAG, "reload failed", e)
            VpnState.fail(e.message)
            shutdown()
        }
    }

    private suspend fun stopVpn() = lock.withLock {
        if (VpnState.status.value == VpnStatus.Stopped) {
            stopSelf()
            return@withLock
        }
        VpnState.set(VpnStatus.Stopping)
        shutdown()
    }

    /** Останавливает ядро, закрывает TUN и сервис. Вызывать под lock. */
    private fun shutdown() {
        runCatching { commandServer?.closeService() }
        runCatching { commandServer?.close() }
        commandServer = null
        runCatching { tunFd?.close() }
        tunFd = null
        NetworkMonitor.setListener(null)
        NetworkMonitor.stop()
        VpnState.set(VpnStatus.Stopped)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun overrideOptions() = OverrideOptions().apply {
        autoRedirect = false
        includePackage = StringArray(emptyList())
        excludePackage = StringArray(emptyList())
    }

    // ─── Уведомление ─────────────────────────────────────────────────────

    private fun showNotification(connected: Boolean) {
        val state = Subscription.state.value
        val serverName = if (state.selectedTag == AUTO_TAG) {
            "Авто — лучший сервер"
        } else {
            state.nodes.find { it.tag == state.selectedTag }?.name ?: "Сервер"
        }
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ApexVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, ApexApp.CHANNEL_VPN)
            .setSmallIcon(R.drawable.ic_stat_apex)
            .setContentTitle(
                getString(if (connected) R.string.notification_connected else R.string.notification_connecting),
            )
            .setContentText(serverName)
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.notification_disconnect), stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    // ─── CommandServerHandler (команды от ядра) ──────────────────────────

    override fun serviceStop() {
        scope.launch { stopVpn() }
    }

    override fun serviceReload() {
        scope.launch { reloadVpn() }
    }

    override fun getSystemProxyStatus(): SystemProxyStatus = SystemProxyStatus().apply {
        available = false
        enabled = false
    }

    override fun setSystemProxyEnabled(isEnabled: Boolean) {}

    override fun writeDebugMessage(message: String?) {
        Log.d(TAG, message.orEmpty())
    }

    // ─── PlatformInterface (что ядро просит у Android) ───────────────────

    override fun localDNSTransport(): LocalDNSTransport = LocalResolver

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

    override fun autoDetectInterfaceControl(fd: Int) {
        // Сокеты ядра идут мимо VPN, иначе получится петля
        protect(fd)
    }

    override fun openTun(options: TunOptions): Int {
        if (prepare(this) != null) error("Нет разрешения на VPN")
        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .setMtu(options.mtu)
            .setConfigureIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE,
                ),
            )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)

        val inet4 = options.inet4Address
        while (inet4.hasNext()) inet4.next().let { builder.addAddress(it.address(), it.prefix()) }
        val inet6 = options.inet6Address
        while (inet6.hasNext()) inet6.next().let { builder.addAddress(it.address(), it.prefix()) }

        if (options.autoRoute) {
            builder.addDnsServer(options.dnsServerAddress.value)
            // Диапазоны маршрутов уже без исключённых адресов — работает на всех версиях Android
            val r4 = options.inet4RouteRange
            if (r4.hasNext()) {
                while (r4.hasNext()) r4.next().let { builder.addRoute(it.address(), it.prefix()) }
            } else if (options.inet4Address.hasNext()) {
                builder.addRoute("0.0.0.0", 0)
            }
            val r6 = options.inet6RouteRange
            if (r6.hasNext()) {
                while (r6.hasNext()) r6.next().let { builder.addRoute(it.address(), it.prefix()) }
            } else if (options.inet6Address.hasNext()) {
                builder.addRoute("::", 0)
            }
        }

        val pfd = builder.establish() ?: error("Android не разрешил создать VPN-интерфейс")
        tunFd?.let { runCatching { it.close() } }
        tunFd = pfd
        return pfd.fd
    }

    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String,
        sourcePort: Int,
        destinationAddress: String,
        destinationPort: Int,
    ): ConnectionOwner {
        // Правила по приложениям в конфиге не используются
        error("not supported")
    }

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        NetworkMonitor.setListener(listener)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        NetworkMonitor.setListener(null)
    }

    override fun getInterfaces(): NetworkInterfaceIterator = collectInterfaces()

    override fun underNetworkExtension(): Boolean = false

    override fun includeAllNetworks(): Boolean = false

    override fun readWIFIState(): WIFIState? = null

    override fun systemCertificates(): StringIterator = loadSystemCertificates()

    override fun clearDNSCache() {}

    override fun sendNotification(notification: BoxNotification) {
        val nm = getSystemService<NotificationManager>() ?: return
        val n = NotificationCompat.Builder(this, ApexApp.CHANNEL_VPN)
            .setSmallIcon(R.drawable.ic_stat_apex)
            .setContentTitle(notification.title)
            .setContentText(notification.body)
            .setAutoCancel(true)
            .build()
        nm.notify(notification.typeID + 100, n)
    }
}
