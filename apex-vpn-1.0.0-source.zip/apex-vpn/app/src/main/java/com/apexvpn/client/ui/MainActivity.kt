package com.apexvpn.client.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.apexvpn.client.ui.theme.Apex
import com.apexvpn.client.ui.theme.ApexTheme
import com.apexvpn.client.vpn.ApexVpnService
import com.apexvpn.client.vpn.VpnState
import com.apexvpn.client.vpn.VpnStatus

enum class Screen { Home, Servers, Settings }

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            ApexVpnService.start(this)
        } else {
            viewModel.showMessage("Без разрешения на VPN подключиться нельзя")
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { connectNow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            ApexTheme {
                Surface(Modifier.fillMaxSize(), color = Apex.Bg) {
                    val sub by viewModel.subscription.collectAsStateWithLifecycle()
                    var screen by rememberSaveable { mutableStateOf(Screen.Home) }

                    if (sub.url.isEmpty()) {
                        SetupScreen(viewModel)
                    } else {
                        BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
                        AnimatedContent(
                            targetState = screen,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "screen",
                        ) { current ->
                            when (current) {
                                Screen.Home -> HomeScreen(
                                    viewModel = viewModel,
                                    onToggle = { toggleVpn() },
                                    onOpenServers = { screen = Screen.Servers },
                                    onOpenSettings = { screen = Screen.Settings },
                                )
                                Screen.Servers -> ServersScreen(viewModel) { screen = Screen.Home }
                                Screen.Settings -> SettingsScreen(viewModel) { screen = Screen.Home }
                            }
                        }
                    }
                    UpdateDialog(viewModel)
                }
            }
        }
    }

    private fun toggleVpn() {
        when (VpnState.status.value) {
            VpnStatus.Started, VpnStatus.Starting -> ApexVpnService.stop(this)
            VpnStatus.Stopping -> Unit
            VpnStatus.Stopped -> {
                VpnState.clearError()
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    connectNow()
                }
            }
        }
    }

    private fun connectNow() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else ApexVpnService.start(this)
    }
}
