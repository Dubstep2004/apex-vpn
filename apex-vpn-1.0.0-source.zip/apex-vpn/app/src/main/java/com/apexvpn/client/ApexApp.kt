package com.apexvpn.client

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.net.ConnectivityManager
import android.os.Build
import androidx.core.content.getSystemService
import com.apexvpn.client.data.Prefs
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.SetupOptions
import java.io.File

class ApexApp : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)

        val workingDir = File(filesDir, "work").apply { mkdirs() }
        val tempDir = File(cacheDir, "box").apply { mkdirs() }
        Libbox.setup(
            SetupOptions().also {
                it.basePath = filesDir.path
                it.workingPath = workingDir.path
                it.tempPath = tempDir.path
                // Обход бага Go на Android: https://github.com/golang/go/issues/68760
                it.fixAndroidStack = BuildConfig.DEBUG ||
                    Build.VERSION.SDK_INT in Build.VERSION_CODES.N..Build.VERSION_CODES.N_MR1 ||
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                it.logMaxLines = 300
                it.debug = BuildConfig.DEBUG
            },
        )
        runCatching { Libbox.redirectStderr(File(workingDir, "stderr.log").path) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService<NotificationManager>()!!.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_VPN,
                    getString(R.string.notification_channel),
                    NotificationManager.IMPORTANCE_LOW,
                ).apply { setShowBadge(false) },
            )
        }
    }

    companion object {
        const val CHANNEL_VPN = "vpn_status"
        lateinit var instance: ApexApp
            private set

        val connectivity: ConnectivityManager
            get() = instance.getSystemService()!!
    }
}
