package com.apexvpn.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.apexvpn.client.data.AUTO_TAG
import com.apexvpn.client.data.Pinger
import com.apexvpn.client.ui.theme.Apex

@Composable
fun ServersScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val sub by viewModel.subscription.collectAsStateWithLifecycle()
    val pings by viewModel.pings.collectAsStateWithLifecycle()
    val pinging by viewModel.pinging.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { if (pings.isEmpty()) viewModel.pingAll() }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = Apex.Text)
            }
            Text("Серверы", color = Apex.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { viewModel.pingAll() }, enabled = !pinging) {
                if (pinging) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Apex.Cyan)
                } else {
                    Icon(Icons.Rounded.NetworkCheck, "Проверить задержку", tint = Apex.Cyan)
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item {
                ServerRow(
                    title = "Авто",
                    subtitle = "Автоматически выбирает самый быстрый сервер",
                    badge = null,
                    ping = null,
                    selected = sub.selectedTag == AUTO_TAG,
                    auto = true,
                ) { viewModel.select(AUTO_TAG); onBack() }
            }
            items(sub.nodes, key = { it.tag }) { node ->
                ServerRow(
                    title = node.name,
                    subtitle = null,
                    badge = node.type,
                    ping = pings[node.tag],
                    selected = sub.selectedTag == node.tag,
                    auto = false,
                ) { viewModel.select(node.tag); onBack() }
            }
        }
    }
}

@Composable
private fun ServerRow(
    title: String,
    subtitle: String?,
    badge: String?,
    ping: Int?,
    selected: Boolean,
    auto: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(shape)
            .background(if (selected) Apex.SurfaceHigh else Apex.Surface)
            .border(1.dp, if (selected) Apex.Cyan else Apex.Outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (auto) {
            Icon(Icons.Rounded.Bolt, null, tint = Apex.Cyan)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = Apex.Text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = Apex.TextDim, fontSize = 12.sp)
            }
            if (badge != null) {
                Spacer(Modifier.height(4.dp))
                TypeBadge(badge)
            }
        }
        if (ping != null) {
            Spacer(Modifier.width(8.dp))
            val text = when (ping) {
                Pinger.NOT_APPLICABLE -> "UDP"
                Pinger.UNREACHABLE -> "нет ответа"
                else -> "$ping мс"
            }
            Text(text, color = pingColor(ping), fontSize = 13.sp)
        }
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Box { Icon(Icons.Rounded.CheckCircle, "Выбран", tint = Apex.Cyan) }
        }
    }
}
